package net.tridroid.fellow.Model;

public class Question {
    String userID;
    String question;

    public Question() {
    }

    public Question(String userID, String question) {
        this.userID = userID;
        this.question = question;
    }

    public String getUserID() {
        return userID;
    }

    public String getQuestion() {
        return question;
    }

}
