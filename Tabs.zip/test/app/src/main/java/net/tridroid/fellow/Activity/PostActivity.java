package net.tridroid.fellow.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import net.tridroid.fellow.Adapter.ListAdapter;
import net.tridroid.fellow.Model.Answer;
import net.tridroid.fellow.Model.GlobalVar;
import net.tridroid.fellow.Model.Question;
import net.tridroid.fellow.R;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class PostActivity extends AppCompatActivity {
    private EditText editText;
    /*private TextView editName;
    private TextView editDate;*/
    private ListView lv;
    private DatabaseReference dbRef;
    private List<Question> questions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Post Question");

// Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        dbRef = database.getReference("Question");
        questions = new ArrayList<>();
        editText = findViewById(R.id.edit_question);
        /*editName = findViewById(R.id.textName);*/
        lv = findViewById(R.id.lv_id);

        /*//Getting current date here
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        TextView textViewDate = findViewById(R.id.textDate);
        GlobalVar.date = currentDate;*/
    }

    public void add_Question(View view) {
        //add is here
        String question = editText.getText().toString();
        /*String username = editName.getText().toString();
        String currentDate = editDate.getText().toString();*/
        Calendar cal = Calendar.getInstance();
        String date = DateFormat.getDateInstance().format(cal.getTime());
        if(TextUtils.isEmpty(question)){
            Toast.makeText(this, "Question is empty", Toast.LENGTH_SHORT).show();
            return;
        }
        else{
            //firebase database ma store garne
            String id = dbRef.push().getKey();
            Question obj = new Question(id, question);
            dbRef.child(id).setValue(obj);
            Toast.makeText(this, "Question posted sucessfully", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }

    }
}