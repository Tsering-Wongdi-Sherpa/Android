package net.tridroid.fellow.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SearchView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import net.tridroid.fellow.Adapter.ListAdapter;
import net.tridroid.fellow.Model.Question;
import net.tridroid.fellow.R;

import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {
    private ListView listView;
    private DatabaseReference dbRef;
    private List<Question> questions;
    private SearchView searchView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Search");
        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        dbRef = database.getReference("Question");
        questions = new ArrayList<>();
        /*editName = findViewById(R.id.textName);*/
        listView = findViewById(R.id.mypost_list);
        searchView = findViewById(R.id.search);
        /*//Getting current date here
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        TextView textViewDate = findViewById(R.id.textDate);
        GlobalVar.date = currentDate;*/
    }
    @Override
    protected void onStart() {
        super.onStart();
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                questions.clear();
                for(DataSnapshot answerSnapshot : dataSnapshot.getChildren()){
                    Question quest = answerSnapshot.getValue(Question.class);
                    questions.add(quest);
                }
                ListAdapter adapter = new ListAdapter(SearchActivity.this,questions);
                listView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        if(searchView != null){
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    search(s);
                    return false;
                }
            });
        }
    }

    private void search(String str) {
        ArrayList<Question> myQuestion = new ArrayList<>();
        for(Question object : questions){
            if(object.getQuestion().toLowerCase().contains(str.toLowerCase())){
                myQuestion.add(object);
            }
        }
        ListAdapter adapter = new ListAdapter(this, myQuestion);
        listView.setAdapter(adapter);
    }

    public void search_Question(View view) {
    }
}