package net.tridroid.fellow.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import net.tridroid.fellow.Adapter.ListAdapter;
import net.tridroid.fellow.Model.GlobalVar;
import net.tridroid.fellow.Model.Question;
import net.tridroid.fellow.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawerLayout;
    ActionBarDrawerToggle toggle;
    NavigationView navigationView;
    public static final String USERNAME = "username";
    public static final String EMAIL = "email";
    public static final String QUESTIOON = "question";
    public static final String USERID = "userID";
    private EditText editText;
    private ListView lv;
    private DatabaseReference dbRef;
    private List<Question> questions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Question");
        Toolbar toolbar = findViewById(R.id.toolbar);

        drawerLayout = findViewById(R.id.drawer);
        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        FloatingActionButton fab = findViewById(R.id.fab);
        toggle = new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.setDrawerIndicatorEnabled(true);
        toggle.syncState();

        // Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        dbRef = database.getReference("Question");
        questions = new ArrayList<>();
        editText = findViewById(R.id.edit_question);
        lv = findViewById(R.id.lv_id);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, PostActivity.class);

                startActivity(i);
            }
        });
        //Setting values in global variables form here
        final GoogleSignInAccount signInAccount = GoogleSignIn.getLastSignedInAccount(this);
        if(signInAccount != null){
            GlobalVar.username = signInAccount.getDisplayName();
            GlobalVar.email = signInAccount.getEmail();
            GlobalVar.photo = signInAccount.getPhotoUrl();

        }

        //list view click event is here
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Question question = questions.get(position);
                Intent intent = new Intent(getApplicationContext(), AnswerActivity.class);
                intent.putExtra(USERID, question.getUserID());
                intent.putExtra(QUESTIOON, question.getQuestion());
                intent.putExtra(USERNAME, signInAccount.getDisplayName());
                intent.putExtra(EMAIL, signInAccount.getEmail());
                startActivity(intent);
            }
        });
    }
    //kun icon click garda kun dekhaune yeha
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        drawerLayout.closeDrawer(GravityCompat.START);
        if(menuItem.getItemId() == R.id.post){
            Toast.makeText(this, "This is post here", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(MainActivity.this, MyPostActivity.class);
            startActivity(i);
        }
        if(menuItem.getItemId() == R.id.search){
            Toast.makeText(this, "This is post here", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(MainActivity.this, SearchActivity.class);
            startActivity(i);
        }
        if(menuItem.getItemId() == R.id.logout){
            signout();

        }
        return true;
    }
    @Override
    protected void onStart() {
        super.onStart();
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                questions.clear();
                for(DataSnapshot questionSnapshot : dataSnapshot.getChildren()){
                    Question obj = questionSnapshot.getValue(Question.class);
                    questions.add(obj);
                }
                ListAdapter adapter = new ListAdapter(MainActivity.this,questions);
                lv.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void signout() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
        startActivity(intent);

    }

}