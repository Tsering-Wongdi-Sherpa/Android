package net.tridroid.fellow.Adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import net.tridroid.fellow.Fragment.MyPostFrag;
import net.tridroid.fellow.Fragment.SearchFrag;

public class NavigationAdapter extends FragmentPagerAdapter {
    private int navsNumber;

    public NavigationAdapter(@NonNull FragmentManager fm, int behavior, int tabs) {
        super(fm, behavior);
        this.navsNumber = tabs;
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position){
            case 0:
                return new MyPostFrag();
            case 1:
                return new SearchFrag();

                default: return null;
        }
    }

    @Override
    public int getCount() {
        return navsNumber;
    }
}
