package net.tridroid.fellow.Adapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import net.tridroid.fellow.Model.Answer;
import net.tridroid.fellow.R;

import java.util.List;

public class AnswerAdapter extends ArrayAdapter<Answer> {
    private Activity context;
    private List<Answer> answerList;

    public AnswerAdapter(Activity context, List<Answer> answerList) {
        super(context, R.layout.item_answer_layout, answerList);
        this.context = context;
        this.answerList = answerList;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View view = inflater.inflate(R.layout.item_answer_layout,null,true);

        TextView answer = view.findViewById(R.id.answer);
        /*TextView user = view.findViewById(R.id.textName);
        TextView date = view.findViewById(R.id.textDate);*/
        Answer ans = answerList.get(position);
        answer.setText(ans.getAnswer());
        /*user.setText(obj.getUsername());
        date.setText(obj.getCurrentDate());*/
        return view;
    }
}

