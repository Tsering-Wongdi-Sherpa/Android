package net.tridroid.fellow.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import net.tridroid.fellow.R;

public class NavHeader extends AppCompatActivity {

    TextView name, mail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.nav_header);

        name = findViewById(R.id.name);
        mail = findViewById(R.id.mail);
        Intent intent = getIntent();
        String fetched_username = intent.getStringExtra(MainActivity.USERNAME);
        String fetched_email = intent.getStringExtra(MainActivity.EMAIL);
        name.setText(fetched_username);
        mail.setText(fetched_email);
    }
}