package net.tridroid.fellow.Model;

public class Answer {
    String answerID;
    String answer;

    public Answer() {
    }

    public Answer(String answerID, String answer) {
        this.answerID = answerID;
        this.answer = answer;
    }

    public String getAnswerID() {
        return answerID;
    }

    public String getAnswer() {
        return answer;
    }
}
