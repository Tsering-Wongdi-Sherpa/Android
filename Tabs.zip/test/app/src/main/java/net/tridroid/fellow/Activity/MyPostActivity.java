package net.tridroid.fellow.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import net.tridroid.fellow.Adapter.AnswerAdapter;
import net.tridroid.fellow.Adapter.ListAdapter;
import net.tridroid.fellow.Model.Answer;
import net.tridroid.fellow.Model.GlobalVar;
import net.tridroid.fellow.Model.Question;
import net.tridroid.fellow.R;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.List;

public class MyPostActivity extends AppCompatActivity {
    /*private TextView editName;
    private TextView editDate;*/
    private ListView listViewQ;
    private DatabaseReference dbRef;
    private List<Question> questions;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_post);
        getSupportActionBar().setTitle("My Post");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

// Write a message to the database
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        dbRef = database.getReference("Question");
        questions = new ArrayList<>();
        /*editName = findViewById(R.id.textName);*/
        listViewQ = findViewById(R.id.mypost_list);

        /*//Getting current date here
        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance(DateFormat.FULL).format(calendar.getTime());
        TextView textViewDate = findViewById(R.id.textDate);
        GlobalVar.date = currentDate;*/
  listViewQ.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
      @Override
      public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
          Question q = questions.get(position);
          showUpdateDialog(q.getUserID(), q.getQuestion());
          return false;
      }
  });

    }

    private void showUpdateDialog(final String userID, final String Question) {
        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(this);
        LayoutInflater inflater = getLayoutInflater();
        final View dialogView = inflater.inflate(R.layout.update, null);
        dialogBuilder.setView(dialogView);
        final TextView textViewName = (TextView) dialogView.findViewById(R.id.prevQuestion);
        final EditText editTextQ = dialogView.findViewById(R.id.updatedQ);
        final Button buttonUpdate = (Button) dialogView.findViewById(R.id.updateBtn);
        final Button buttonDelete = (Button) dialogView.findViewById(R.id.delete);


        dialogBuilder.setTitle("Updating The Question of ID " + userID);

        final AlertDialog alertDialog = dialogBuilder.create();
        alertDialog.show();
        buttonUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String que = editTextQ.getText().toString().trim();
                //Log.i(que);
                Log.i("this", que);
                if(TextUtils.isEmpty(que)) {
                    editTextQ.setError("Updated Question Required");
                    return;
                }
                else {
                    updateQ(userID, que);

                    alertDialog.dismiss();
                }

            }
        });

        buttonDelete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                deleteQuestion(userID);
            }
        });



    }

    private  void deleteQuestion (String uId) {
        DatabaseReference que = FirebaseDatabase.getInstance().getReference("Question").child(uId);
        que.removeValue();

        Toast.makeText(this, "Question Deleted", Toast.LENGTH_LONG).show();
    }

    private boolean updateQ(String id, String name) {
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Question").child(id);
        Question question = new Question(id, name);
        databaseReference.setValue(question);
        Toast.makeText(this, "Question Updated Successfully" , Toast.LENGTH_LONG).show();
        return true;
    }

    @Override
    protected void onStart() {
        super.onStart();
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                questions.clear();
                for(DataSnapshot answerSnapshot : dataSnapshot.getChildren()){
                    Question quest = answerSnapshot.getValue(Question.class);
                    questions.add(quest);
                }
                ListAdapter adapter = new ListAdapter(MyPostActivity.this,questions);
                listViewQ.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}