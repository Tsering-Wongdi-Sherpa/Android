package net.tridroid.fellow.Model;

import android.media.Image;
import android.net.Uri;

public class GlobalVar {
    public static String username;
    public static String email;
    public static Uri photo;
    public static String date;

    public GlobalVar() {
    }

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        GlobalVar.username = username;
    }

    public static String getEmail() {
        return email;
    }

    public static void setEmail(String email) {
        GlobalVar.email = email;
    }

    public static Uri getPhoto() {
        return photo;
    }

    public static void setPhoto(Uri photo) {
        GlobalVar.photo = photo;
    }

    public static String getDate() {
        return date;
    }

    public static void setDate(String date) {
        GlobalVar.date = date;
    }
}
